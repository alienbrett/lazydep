# lazydep
Lazily evaluate function dependency graph
